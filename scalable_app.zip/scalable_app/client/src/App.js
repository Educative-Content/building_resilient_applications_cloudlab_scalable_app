// Import Bootstrap CSS
import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css'; // Import your CSS file for styling

const Header = () => {
  return (
    <div className="header">
      Hospital's Database
    </div>
  );
}

function App() {
  const [patients, setStudents] = useState([]);
  const [name, setName] = useState('');
  const [rollNumber, setRollNumber] = useState('');

  useEffect(() => {
    axios.get('/patients')
      .then((response) => setStudents(response.data.patients))
      .catch((error) => console.error(error));
  }, []);

  const addStudent = () => {
    axios.post('/patients', { name, rollNumber })
      .then((response) => {
        setStudents([...patients, { id: response.data.studentId, name, patient_number: rollNumber }]);
        setName('');
        setRollNumber('');
      })
      .catch((error) => console.error(error));
  };

  return (
    <div>
      <Header /> {/* Include the Header component */}
      <div className="input-container">
        <input type="text" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} />
        <input type="number" placeholder="Patient Number" value={rollNumber} onChange={(e) => setRollNumber(e.target.value)} />
        <button onClick={addStudent}>Add Patient</button>
      </div>
      <div className="table-container">
        {/* Use Bootstrap table */}
        <table className="table">
          <thead>
            <tr>
              <th>Patient ID</th>
              <th>Name</th>
              <th>Patient Number</th>
            </tr>
          </thead>
          <tbody>
            {patients.map((patient) => (
              <tr key={patient.id}>
                <td>{patient.id}</td>
                <td>{patient.name}</td>
                <td>{patient.patient_number}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default App;
