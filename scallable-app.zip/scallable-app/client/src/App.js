import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css'; // Import your CSS file for styling

const Header = () => {
  return (
    <div className="header">
      Student Database
    </div>
  );
}




function App() {
  const [students, setStudents] = useState([]);
  const [name, setName] = useState('');
  const [rollNumber, setRollNumber] = useState('');

  useEffect(() => {
    axios.get('/students')
      .then((response) => setStudents(response.data.students))
      .catch((error) => console.error(error));
  }, []);

  const addStudent = () => {
    axios.post('/students', { name, rollNumber })
      .then((response) => {
        setStudents([...students, { id: response.data.studentId, name, roll_number: rollNumber }]);
        setName('');
        setRollNumber('');
      })
      .catch((error) => console.error(error));
  };

  return (
    <div>
      <Header /> {/* Include the Header component */}
      <div className="input-container">
        <input type="text" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} />
        <input type="number" placeholder="Roll Number" value={rollNumber} onChange={(e) => setRollNumber(e.target.value)} />
        <button onClick={addStudent}>Add Student</button>
      </div>
      <ul>
        {students.map((student) => (
          <li key={student.id}>
            {student.name} - Roll Number: {student.roll_number}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
